function init(){
    insertChapters();
    loadChapter();
}