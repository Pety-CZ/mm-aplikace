// (function (){
    
    /*let video = document.querySelector('video');*/

    if (questions){

    }

    var questions = [
        [false,
            2,
            "<p>NE?</p><ul><li><input type='radio' name='q1' value='a'> A) ANO</li><li><input type='radio' name='q1' value='b'> B) NE</li></ul>",
            "b"
        ],
        [false,
            4,
            "<p>ANO?</p><ul><li><input type='radio' name='q2' value='a'> A) ANO</li><li><input type='radio' name='q2' value='b'> B) NE</li></ul>",
            "a"
        ],
    ];


    function loadQuizForChapter(index) {
        document.getElementById('quiz-container').innerHTML = questions[index][2] + `<button onclick="checkQuiz(${index})">Odeslat</button>`;
    }

    function checkQuiz(index) {
        let answer = document.querySelector(`input[name="q${index + 1}"]:checked`);

        if (answer && answer.value == questions[index][3]) {
            document.getElementById('video').play();

            let quiz = document.getElementById('quiz-container');
            quiz.innerHTML = "<p style='color: green;'>Správně!</p>" + quiz.innerHTML;
            questions[index][0] = true;
        } else {
            alert("Špatně, zkus to znovu.");
        }
    }

// video.addEventListener('timeupdate', () => {

//     questions.forEach((question, index) => {
//         if (video.currentTime >= question[1] && question[0] == false) {
//             video.pause();
//             loadQuizForChapter(index);
//         }
//     });
// });
    var currentQuizHandler = null;
    attachQuizHandler(questions);

    video.addEventListener('timeupdate', currentQuizHandler);
    // video.addEventListener('timeupdate', attachQuizHandler(questions));
    console.log("1.1.js loaded");
    // let currentQuizHandler = null;
    attachQuizHandler(questions);

    function attachQuizHandler(questions) {
        console.log("attachQuizHandler called");
        const video = document.querySelector('video');

        if (currentQuizHandler) {
            console.log("Removing previous event listener: " + currentQuizHandler);
            video.removeEventListener('timeupdate', currentQuizHandler);
        }

        currentQuizHandler = function () {
            questions.forEach((q, index) => {
                if (video.currentTime >= q[1] && !q[0]) {
                    video.pause();
                    loadQuiz(index, questions);
                }
            });
        };
    }